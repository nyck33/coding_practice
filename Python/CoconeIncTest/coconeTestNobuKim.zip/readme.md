readme.md

pip install -r requirements.txt
にてバーチャル環境を作ってください。Pythonのバージョンは3.6以上にてお願い致します。

各プログラムの実行コマンドは以下です。

python words.py
python bulletsVsMonsters.py
python specialAttackCircleSector.py

上記コマンドにて作動しない場合は以下を実行してみてください。
python3 words.py
python3 bulletsVsMonsters.py
python3 specialAttackCircleSector.py


